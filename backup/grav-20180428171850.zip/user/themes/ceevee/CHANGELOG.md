# v1.3.0
## 07/14/2016

1. [](#improved)
    * Remove unneeded streams from Theme YAML
    * Delete unused composer.json
1. [](#bugfix)
    * Fix setting the page language in the html tag
    
# v1.2.0
## 01/06/2016

1. [](#improved)
    * Updated to Fontawesome 4.5.0
1. [](#bugfix)
	* Fix typos
	* Fixed duplicate property

# v1.1.0
## 12/18/2015

1. [](#improved)
    * use `|safe_email` filter
1. [](#bugfix)
	* Twitter widget fails to load with HTTPS
	* Closing the menu puts you back at the top
	* Fix for stuck at "Thank You" after submitting form

# v1.0.0
## 10/26/2015

1. [](#new)
    * ChangeLog started...
