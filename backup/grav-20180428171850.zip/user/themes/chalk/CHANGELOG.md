# v0.2.0
##  04/05/2018

1. [](#new)
    * Fixed icons
    * Several improvements
    * Fixed scss reference to normalize
    
# v0.1.0
##  03/18/2018

1. [](#new)
    * ChangeLog started...
