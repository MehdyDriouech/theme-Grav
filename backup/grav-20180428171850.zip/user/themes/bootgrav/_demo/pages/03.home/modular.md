---
title: Home
body_classes: modular
content:
    order:
        dir: desc
        by: date
    items: '@self.modular'
---

