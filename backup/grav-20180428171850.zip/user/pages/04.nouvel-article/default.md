---
title: 'Nouvel article'
published: true
googletitle: 'Nouvel article'
googledesc: 'Un nouvel article du site Geekbuystuff en utiilisant le CMS Grav :)'
twittercardoptions: summary
articleenabled: false
musiceventenabled: false
orgaenabled: false
orga:
    ratingValue: 2.5
orgaratingenabled: false
eventenabled: false
personenabled: false
restaurantenabled: false
restaurant:
    acceptsReservations: 'yes'
    priceRange: $
---

# Un nouvel article 
Salut a toutes et a tous ! ceci est un test du cms **Grav** !